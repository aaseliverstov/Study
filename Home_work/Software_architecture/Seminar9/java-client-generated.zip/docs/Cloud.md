# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloudId** | **String** |  |  [optional]
**idClient** | **String** |  | 
**os** | [**OsEnum**](#OsEnum) | Операционная система сервера | 
**RAM** | **String** | Объем оперативной памяти | 
**CPU** | **String** | Количество ядер процессора | 

<a name="OsEnum"></a>
## Enum: OsEnum
Name | Value
---- | -----
WINDOWS | &quot;Windows&quot;
LINUX | &quot;Linux&quot;
